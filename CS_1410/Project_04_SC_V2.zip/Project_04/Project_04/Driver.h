/* File Prolog
Name: Spencer Carter
Assignment: Project 04
Class: CS 1410 Section 003
Date: 10/15/2015

I declare that the following code was written by me, assisted with
by the lovely people in the drop in lab, and/or provided by the instructior
for this project. I understand that copying source code from any other
source constitutes cheating, and that I will recieve a zero on this
project if I am found in violation of this policy.
*/

#pragma once
#include "MyVector.h"		// the Vector class we will be testing
#include <iostream>			// std::cout
using namespace std;

	const int TEST_VALUE1 = 21;
	const int TEST_VALUE2 = 31;
	const int TEST_VALUE3 = 41;
	const int MAX = 12;